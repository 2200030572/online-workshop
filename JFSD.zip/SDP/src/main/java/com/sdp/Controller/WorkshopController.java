package com.sdp.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.sdp.model.Feedback;
import com.sdp.model.Workshop;
import com.sdp.service.WorkshopService;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/workshops")
public class WorkshopController {

    private final WorkshopService workshopService;

    @Autowired
    public WorkshopController(WorkshopService workshopService) {
        this.workshopService = workshopService;
    }

    @GetMapping
    public List<Workshop> getAllWorkshops() {
        return workshopService.getAllWorkshops();
    }

    @GetMapping("/search")
    public List<Workshop> searchWorkshops(@RequestParam String searchTerm) {
        return workshopService.getFilteredWorkshops(searchTerm);
    }

    @GetMapping("/{id}")
    public Workshop getWorkshopById(@PathVariable Long id) {
        return workshopService.getWorkshopById(id);
    }

    @GetMapping("/{workshopId}/feedback")
    public List<Feedback> getFeedback(@PathVariable Long workshopId) {
        return workshopService.getFeedbackForWorkshop(workshopId);
    }

    @PostMapping("/{workshopId}/feedback")
    public ResponseEntity<String> submitFeedback(
            @PathVariable Long workshopId,
            @RequestBody Feedback feedback) {
        workshopService.submitFeedback(workshopId, feedback);
        return ResponseEntity.ok("Feedback submitted successfully");
    }

    @GetMapping("/myworkshops")
    public ResponseEntity<List<Workshop>> getMyWorkshops(@RequestParam Long userId) {
        List<Workshop> workshops = workshopService.getWorkshopsByUserId(userId);
        return ResponseEntity.ok(workshops);
    }
}
