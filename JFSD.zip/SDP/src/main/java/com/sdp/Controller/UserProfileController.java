package com.sdp.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.sdp.model.UserProfile;
import com.sdp.service.UserProfileService;

@RestController
@RequestMapping("/api/user")
public class UserProfileController {

    @Autowired
    private UserProfileService userProfileService;

    // Get user profile
    @GetMapping("/{userId}/profile")
    public ResponseEntity<UserProfile> getUserProfile(@PathVariable Long userId) {
        UserProfile userProfile = userProfileService.getUserProfile(userId);
        if (userProfile != null) {
            return ResponseEntity.ok(userProfile);
        }
        return ResponseEntity.status(404).body(null);
    }

    // Update user profile
    @PutMapping("/{userId}/profile")
    public ResponseEntity<UserProfile> updateUserProfile(@PathVariable Long userId, @RequestBody UserProfile updatedProfile) {
        UserProfile updatedUserProfile = userProfileService.updateUserProfile(userId, updatedProfile);
        if (updatedUserProfile != null) {
            return ResponseEntity.ok(updatedUserProfile);
        }
        return ResponseEntity.status(400).body(null);
    }
}

