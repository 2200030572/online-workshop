package com.sdp.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sdp.Repository.UserProgressRepository;
import com.sdp.model.UserProgress;

import java.util.List;

@Service
public class UserProgressService {

    @Autowired
    private UserProgressRepository userProgressRepository;

    public List<UserProgress> getUserProgress(Long userId) {
        return userProgressRepository.findByUserId(userId);
    }
}

