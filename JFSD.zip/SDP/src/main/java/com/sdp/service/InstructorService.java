package com.sdp.service;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sdp.Repository.InstructorRepository;
import com.sdp.model.Instructor;

@Service
public class InstructorService {
 @Autowired
 private InstructorRepository instructorRepository;

 public Instructor getInstructorById(Long id) {
     return instructorRepository.findById(id).orElse(null);
 }
}

