package com.sdp.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.sdp.model.Progress;
import com.sdp.service.ProgressService;

import java.util.List;

@RestController
@RequestMapping("/api/progress")
@CrossOrigin(origins = "http://localhost:3000")  // Replace with your React app's URL
public class ProgressController {

 @Autowired
 private ProgressService progressService;

 @GetMapping("/user/{userId}")
 public List<Progress> getUserProgress(@PathVariable Long userId) {
     return progressService.getUserProgress(userId);
 }

 @PostMapping("/update")
 public Progress updateProgress(@RequestParam Long userId, 
                                @RequestParam Long workshopId,
                                @RequestParam int progressPercentage) {
     return progressService.updateProgress(userId, workshopId, progressPercentage);
 }
}
