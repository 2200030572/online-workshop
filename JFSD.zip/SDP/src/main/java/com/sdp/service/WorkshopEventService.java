package com.sdp.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sdp.Repository.WorkshopEventRepository;
import com.sdp.model.WorkshopEvent;

import java.util.List;

@Service
public class WorkshopEventService {

    @Autowired
    private WorkshopEventRepository workshopEventRepository;

    public List<WorkshopEvent> getAllEvents() {
        return workshopEventRepository.findAll();
    }
}

