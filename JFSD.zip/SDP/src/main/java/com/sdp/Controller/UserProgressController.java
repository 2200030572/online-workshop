package com.sdp.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.sdp.model.UserProgress;
import com.sdp.service.UserProgressService;

import java.util.List;

@RestController
@RequestMapping("/api/progress")
public class UserProgressController {

    @Autowired
    private UserProgressService userProgressService;

    @GetMapping("/{userId}")
    public List<UserProgress> getUserProgress(@PathVariable Long userId) {
        return userProgressService.getUserProgress(userId);
    }
}

