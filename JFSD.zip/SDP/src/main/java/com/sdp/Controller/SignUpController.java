package com.sdp.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.sdp.Repository.UserRepository;
import com.sdp.model.User;

@RestController
@RequestMapping("/api/auth")
public class SignUpController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/signup")
    public ResponseEntity<String> registerUser(@RequestBody User signUpRequest) {
        if (userRepository.findByEmail(signUpRequest.getEmail()) != null) {
            return ResponseEntity.status(400).body("Email is already in use.");
        }

        // Save user to the database
        userRepository.save(signUpRequest);
        return ResponseEntity.status(201).body("Sign up successful!");
    }
}

