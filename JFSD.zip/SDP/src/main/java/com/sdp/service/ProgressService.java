package com.sdp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sdp.Repository.ProgressRepository;
import com.sdp.model.Progress;

import java.util.List;

@Service
public class ProgressService {

 @Autowired
 private ProgressRepository progressRepository;

 public List<Progress> getUserProgress(Long userId) {
     return progressRepository.findByUserId(userId);
 }

 public Progress updateProgress(Long userId, Long workshopId, int progressPercentage) {
     Progress progress = progressRepository
         .findByUserId(userId)
         .stream()
         .filter(p -> p.getWorkshopId().equals(workshopId))
         .findFirst()
         .orElse(new Progress(userId, workshopId, 0));
     progress.setProgressPercentage(progressPercentage);
     return progressRepository.save(progress);
 }
}
