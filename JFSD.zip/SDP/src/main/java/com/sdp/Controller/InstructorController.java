package com.sdp.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.sdp.model.Instructor;
import com.sdp.service.InstructorService;

@RestController
@RequestMapping("/api/instructors")
public class InstructorController {
 @Autowired
 private InstructorService instructorService;

 @GetMapping("/{id}")
 public Instructor getInstructorById(@PathVariable Long id) {
     return instructorService.getInstructorById(id);
 }
}

