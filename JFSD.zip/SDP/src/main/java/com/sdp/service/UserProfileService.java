package com.sdp.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sdp.Repository.UserProfileRepository;
import com.sdp.model.UserProfile;

@Service
public class UserProfileService {

    @Autowired
    private UserProfileRepository userProfileRepository;

    public UserProfile getUserProfile(Long userId) {
        return userProfileRepository.findByUserId(userId);
    }

    public UserProfile updateUserProfile(Long userId, UserProfile updatedProfile) {
        UserProfile currentProfile = userProfileRepository.findByUserId(userId);

        if (currentProfile != null) {
            currentProfile.setName(updatedProfile.getName());
            currentProfile.setEmail(updatedProfile.getEmail());
            currentProfile.setPhone(updatedProfile.getPhone());
            currentProfile.setBio(updatedProfile.getBio());
            currentProfile.setProfilePicture(updatedProfile.getProfilePicture()); // Handle profile picture

            return userProfileRepository.save(currentProfile);
        }
        return null;
    }
}
