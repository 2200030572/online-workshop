package com.sdp.Controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.sdp.model.Notification;
import com.sdp.model.User;
import com.sdp.service.NotificationService;
import com.sdp.service.UserService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
 @Autowired
 private NotificationService notificationService;

 @Autowired
 private UserService userService;

 
 @GetMapping("/{username}")
 public List<Notification> getNotificationsForUser(@PathVariable String username) {
     Optional<User> user = userService.findByUsername(username);  // No more Optional
     return notificationService.getNotificationsByUser(user);
 }

}
