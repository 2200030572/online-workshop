package com.sdp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sdp.Repository.FeedbackRepository;
import com.sdp.Repository.WorkshopRepository;
import com.sdp.model.Feedback;
import com.sdp.model.Workshop;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class WorkshopService {

    private final WorkshopRepository workshopRepository;
    private final FeedbackRepository feedbackRepository;

    @Autowired
    public WorkshopService(WorkshopRepository workshopRepository, FeedbackRepository feedbackRepository) {
        this.workshopRepository = workshopRepository;
        this.feedbackRepository = feedbackRepository;
    }

    public List<Workshop> getAllWorkshops() {
        return workshopRepository.findAll();
    }

    public List<Workshop> getFilteredWorkshops(String searchTerm) {
        List<Workshop> workshops = workshopRepository.findAll();
        return workshops.stream()
                .filter(workshop -> workshop.getTitle().toLowerCase().contains(searchTerm.toLowerCase()) ||
                        workshop.getDescription().toLowerCase().contains(searchTerm.toLowerCase()))
                .collect(Collectors.toList());
    }
    
    public Workshop getWorkshopById(Long id) {
        return workshopRepository.findById(id).orElse(null);
    }

    public List<Workshop> searchWorkshops(String term) {
        return workshopRepository.findByTitleContainingIgnoreCaseOrDescriptionContainingIgnoreCase(term, term);
    }

    public List<Feedback> getFeedbackForWorkshop(Long workshopId) {
        return feedbackRepository.findByWorkshop_Id(workshopId);  // Ensure correct method in FeedbackRepository
    }

    public void submitFeedback(Long workshopId, Feedback feedback) {
        Workshop workshop = workshopRepository.findById(workshopId)
                .orElseThrow(() -> new RuntimeException("Workshop not found"));
        feedback.setWorkshop(workshop);
        feedbackRepository.save(feedback);
    }

    public List<Workshop> getWorkshopsByUserId(Long userId) {
        return workshopRepository.findByUserId(userId);
    }

}
