package com.sdp.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Data
@Entity
public class Workshop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String description;
    private String date;
    private String location;
    private String videoUrl; // URL for the video (optional)
    
    @Column(name = "user_id")
    private Long userId;
    @ManyToOne
    @JoinColumn(name = "instructor_id")
    private Instructor instructor;

    public Workshop() {}

    // Constructor with only id
    public Workshop(Long id) {
        this.id = id;
    }

    // Constructor with id, title, and description
    public Workshop(Long id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
    }

    // Getters and setters (Lombok generates these if using @Data annotation)
}
