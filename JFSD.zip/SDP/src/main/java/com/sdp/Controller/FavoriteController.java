package com.sdp.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.sdp.Repository.UserFavoriteRepository;
import com.sdp.model.User;
import com.sdp.model.UserFavorite;
import com.sdp.model.Workshop;

import java.util.List;

@RestController
@RequestMapping("/api/favorites")
public class FavoriteController {

    @Autowired
    private UserFavoriteRepository userFavoriteRepository;

    // Get all favorite workshops for a user
    @GetMapping("/{userId}")
    public List<UserFavorite> getFavorites(@PathVariable Long userId) {
        return userFavoriteRepository.findByUserId(userId);
    }
    // Add a favorite workshop
    @PostMapping("/{userId}/{workshopId}")
    public ResponseEntity<?> addFavorite(@PathVariable Long userId, @PathVariable Long workshopId) {
        UserFavorite favorite = new UserFavorite();
        favorite.setUser(new User(userId));  // Create User with id only
        favorite.setWorkshop(new Workshop(workshopId));  // Create Workshop with id only
        userFavoriteRepository.save(favorite);
        return ResponseEntity.ok("Workshop added to favorites");
    }

    // Remove a favorite workshop
    @DeleteMapping("/{userId}/{workshopId}")
    public ResponseEntity<?> removeFavorite(@PathVariable Long userId, @PathVariable Long workshopId) {
        userFavoriteRepository.deleteByUserIdAndWorkshopId(userId, workshopId);
        return ResponseEntity.ok("Workshop removed from favorites");
    }
}
