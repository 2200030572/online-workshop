package com.sdp.Controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sdp.model.Testimonial;
import com.sdp.service.TestimonialService;

import java.util.List;

@RestController
public class TestimonialController {

    private final TestimonialService testimonialService;

    @Autowired
    public TestimonialController(TestimonialService testimonialService) {
        this.testimonialService = testimonialService;
    }

    @GetMapping("/api/testimonials")
    public List<Testimonial> getTestimonials() {
        return testimonialService.getAllTestimonials();
    }
}
