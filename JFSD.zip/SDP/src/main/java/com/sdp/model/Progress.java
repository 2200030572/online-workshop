package com.sdp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class Progress {
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;

 private Long userId;
 private Long workshopId;
 private int progressPercentage;

 // Constructors, getters, and setters
 public Progress() {}

 public Progress(Long userId, Long workshopId, int progressPercentage) {
     this.userId = userId;
     this.workshopId = workshopId;
     this.progressPercentage = progressPercentage;
 }

 public Long getId() {
     return id;
 }

 public Long getUserId() {
     return userId;
 }

 public Long getWorkshopId() {
     return workshopId;
 }

 public int getProgressPercentage() {
     return progressPercentage;
 }

 public void setProgressPercentage(int progressPercentage) {
     this.progressPercentage = progressPercentage;
 }
}

