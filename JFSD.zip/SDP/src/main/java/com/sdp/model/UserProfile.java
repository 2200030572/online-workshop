package com.sdp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToOne;
import lombok.Data;

@Data
@Entity
public class UserProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String phone;
    private String bio;

    @Lob
    private byte[] profilePicture; // Store image as byte array (you can also store the image URL if using a cloud service)

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

    // Getters and setters
}

