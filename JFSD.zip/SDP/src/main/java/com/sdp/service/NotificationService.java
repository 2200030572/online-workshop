package com.sdp.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sdp.Repository.NotificationRepository;
import com.sdp.model.Notification;
import com.sdp.model.User;

import java.util.List;
import java.util.Optional;

@Service
public class NotificationService {
 @Autowired
 private NotificationRepository notificationRepository;

 public List<Notification> getNotificationsByUser(Optional<User> user) {
     return notificationRepository.findByUser(user);
 }
}
