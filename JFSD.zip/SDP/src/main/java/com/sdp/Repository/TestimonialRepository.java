package com.sdp.Repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sdp.model.Testimonial;

public interface TestimonialRepository extends JpaRepository<Testimonial, Long> {
    List<Testimonial> findAll();  // Fetch all testimonials
}

