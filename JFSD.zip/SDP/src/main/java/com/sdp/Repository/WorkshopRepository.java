package com.sdp.Repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sdp.model.Feedback;
import com.sdp.model.User;
import com.sdp.model.Workshop;

public interface WorkshopRepository extends JpaRepository<Workshop, Long> {

    List<Workshop> findByTitleContainingIgnoreCaseOrDescriptionContainingIgnoreCase(String title, String description);

    List<Workshop> findByUserId(Long userId); // Retrieves workshops by userId

    List<Workshop> findAll(); // Retrieves all workshops

    List<Workshop> findByUser(User user); // Retrieves workshops by User entity

    @Query("SELECT w FROM Workshop w WHERE w.id = :id")
    List<Workshop> findWorkshopById(@Param("id") Long id);
}
