package com.sdp.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

//Event.java

@Entity
public class Event {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;
 
 private String title;
 
 @Temporal(TemporalType.TIMESTAMP)
 private Date start;
 
 @Temporal(TemporalType.TIMESTAMP)
 private Date end;

 // Getters and Setters
}
