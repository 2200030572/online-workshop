package com.sdp.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.sdp.model.WorkshopEvent;
import com.sdp.service.WorkshopEventService;

import java.util.List;

@RestController
@RequestMapping("/api/events")
public class WorkshopEventController {

    @Autowired
    private WorkshopEventService workshopEventService;

    @GetMapping
    public List<WorkshopEvent> getEvents() {
        return workshopEventService.getAllEvents();
    }
}
