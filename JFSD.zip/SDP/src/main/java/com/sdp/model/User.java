package com.sdp.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;


@Data
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String email;

    private String password;
    private String username;
    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id")  // Assuming "id" is the primary key of the User entity
    private User user;

    public User() {}

    // Constructor with id
    public User(Long id) {
        this.id = id;
    }

    // Getters and setters
}
