package com.sdp.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sdp.model.FAQ;

public interface FAQRepository extends JpaRepository<FAQ, Long> {
}
